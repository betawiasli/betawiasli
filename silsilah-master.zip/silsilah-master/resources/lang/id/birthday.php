<?php

return [
    'birthday'    => 'Ulang Tahun',
    'upcoming'    => 'Ulang tahun akan datang',
    'no_upcoming' => 'Belum ada ulang tahun dalam :days hari kedepan.',
    'remaining'   => ':count hari',
    'age_years'   => ':age tahun',
    'days'        => 'Hari',
];
