<?php

return [
    // Labels
    'show'               => 'Lhat Profil Pernikahan',
    'detail'             => 'Profil Pernikahan',
    'childs_count'       => 'Jumlah Anak',
    'grand_childs_count' => 'Jumlah Cucu',

    // Actions
    'edit'               => 'Edit Pernikahan',
    'update'             => 'Update Pernikahan',

    // Attributes
    'husband'            => 'Kepala Keluarga',
    'wife'               => 'Isteri',
    'marriage_date'      => 'Tanggal Pernikahan',
    'divorce_date'       => 'Tanggal Perceraian',
];